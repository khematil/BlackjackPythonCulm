#Imports
import random
import easygui as eg
import sys

#Dealer cards
def dc():
    dealercards = []  #creates list for dealer cards
    return(dealercards)
#Player Cards
def pc():
    playercards = []  #creates list for player cards
    return (playercards)
def gamble(money):
    while True: #debugging code so that the user cant input any letters
        try:
            #enterbox for amount gambled
            eg.msgbox("The amount of money you have is ${0}".format(money),"Blackjack")
            moneygamble = int(eg.enterbox("Enter amount you would like to gamble!","Blackjack"))
            if moneygamble > money: #if number more than 10000 then it will display this msg
                eg.msgbox("You don't have that much. You only have 10000")
            elif moneygamble <= 0:  #if number more than 10000 then it will display this msg
                eg.msgbox ("You can't gamble this amount!")
            else:
                break
        except ValueError: #if the user doesnt put in anything but a number it says this response
            eg.msgbox("Oops! That was no valid amount. Try again...")
    return(moneygamble,money)


#Dealer Cards
def dealerdraw(dealercards):
    while len(dealercards) != 2: #while the length of the list doesn't equal 2
        dealercards.append(random.randint(1,11)) #random integers from 1- 11
        if len(dealercards) == 2: #when it reaches 2 it will display this message
            eg.msgbox("The Dealer has: [Hidden] and {0}".format(dealercards[1]),"Blackjack")
            return (dealercards)
#Player Cards
def playerdraw(playercards):
    while len(playercards) != 2: #while the lngth of the list != 2
        playercards.append(random.randint(1,11)) #random integers from 1-11
        if len(playercards) == 2: #once reached will display this
            eg.msgbox("You have: {0}".format(playercards),"Blackjack")
#Sum of the Dealer
def sumdealer(dealercards,money,dealermoney,moneygamble):
    if sum(dealercards) == 21: #if dealer gets 21 then he auto wins
        eg.msgbox("Oh no! The Dealer Got 21! He won!","Blackjack")
        money = money - moneygamble #the money gambled is taken from the player
        dealermoney = dealermoney + moneygamble #then added to the the dealersmoney
        eg.msgbox("The amount of money you have left is {0} and the amount the dealer has is {1}".format(money,dealermoney))
        if money <=0: #if money <= 0 it will end the game
            eg.msgbox ("GAMEOVER! You lost all of the money!","Game Over!", image = "GameOver.gif" )
            quit()

    elif sum(dealercards) > 21: #if the user goes over 21 he'll bust
        eg.msgbox("Congratulations! The Dealer Busted! You Win")
        money = money + moneygamble #will add money gambled to player money
        dealermoney = dealermoney - moneygamble #subtract moneygambled from dealermoney
        eg.msgbox("The amount of money you have left is {0} and the amount the dealer has is {1}".format(money,dealermoney))
        if dealermoney <=0: #if money <= 0 it will end the game
            eg.msgbox ("You Won all of the money! Good Game!", image = "giphy.gif")
            quit()
    return(dealercards,money,dealermoney,moneygamble)


#Sum of the Player
def sumplayer(playercards,dealercards,money,dealermoney,moneygamble):
    while sum(playercards) <21: #if the player has a total thats less than 21
    #it will ask to hit or stay
        hitorstay = eg.buttonbox("Would you like to hit or stay?","Blackjack",("Hit","Stay"))
        if hitorstay == "Hit":
            playercards.append(random.randint(1,11)) #adds another integer to the list
            eg.msgbox("Your cards are now " + str(playercards)) #displays cards
        elif hitorstay == "Stay": #if stay is selected then  the cards chosen are kept
                eg.msgbox("The Dealer's cards are " + str(dealercards)) #displays dealers cards
                eg.msgbox("Your cards are " + str(playercards)) #displays users cards
                if sum(dealercards) > sum(playercards): #if dealer has a higher total player loses
                    eg.msgbox("You Lose! Congratulations")
                    money = money - moneygamble #player loses money
                    dealermoney = dealermoney + moneygamble #dealer gains money
                    eg.msgbox("The amount of money you have left is {0} and the amount the dealer has is {1}".format(money,dealermoney))
                    if money <=0:
                        eg.msgbox ("You lost all of the money!","Game Over!", image = "GameOver.gif") #if player loses all the money this msg appears
                        quit()

                    break
                elif sum(dealercards) < sum(playercards): #if player wins
                    eg.msgbox ("You Win! Yay!")
                    money = money + moneygamble #gain money
                    dealermoney = dealermoney - moneygamble
                    #displays amount of money both players have
                    eg.msgbox("The amount of money you have left is {0} and the amount the dealer has is {1}".format(money,dealermoney))
                    if dealermoney <=0: #if dealer has no money

                        eg.msgbox ("You Won all of the money! Good Game!", image = "giphy.gif")
                        quit()

                    break


    if sum(playercards) > 21: #if player goes over 21 they bust
        eg.msgbox("You went over 21 and busted! Dealer Wins!")
        money = money - moneygamble #gives money to the dealer
        dealermoney = dealermoney + moneygamble
        eg.msgbox("The amount of money you have is {0} and the amount the dealer has is {1}".format(money,dealermoney))
        if money <=0: #game over if player loses

            eg.msgbox ("You Lost all of the money!", image = "GameOver.gif")
            quit()

    elif sum(playercards) == 21: #if player gets 21 they get "blackjack"
        eg.msgbox("You won! You got Blackjack")
        money = money + moneygamble
        dealermoney = dealermoney - moneygamble
        eg.msgbox("The amount of money you have is {0} and the amount the dealer has is {1}".format(money,dealermoney))
        if dealermoney <=0: #winner message
            eg.msgbox ("You Won all of the money! Good Game!",image = "giphy.gif")
            quit()

    return (playercards,dealercards,money,dealermoney,moneygamble)
#Game Loop
def main():
    #run = True
    #defined variables
    money = 10000
    dealermoney = 10000
    instructions = eg.msgbox("1. User is asked amount they'd like to bet \n2. User and dealer both receive two cards \n3. If user has the value closest to 21 or exactly 21 they win\n4. If dealer has the closest value to 21 or exact 21 they win.\n5. If either player or dealer goes over 21 either one loses.","Instructions")
    while True:
        #user asked to play after every game
        yesno = eg.buttonbox("Would you like to play?","Blackjack",("Yes","No"), image = "21bj.gif")
        if yesno == "No":
            break
        elif yesno == "Yes": #main loop with all the funtions
            dealercards = dc()
            playercards = pc()
            moneygamble,money = gamble(money)
            dealerdraw(dealercards)
            playerdraw(playercards)
            dealercards,money,dealermoney,moneygamble = sumdealer(dealercards,money,dealermoney,moneygamble)
            playercards,dealercards,money,dealermoney,moneygamble = sumplayer(playercards,dealercards,money,dealermoney,moneygamble)
        elif money <= 0:
            eg.msgbox("You lost all of your money!")
            quit()
        if dealermoney <=0:
            eg.msgbox ("You Won all of the money!")
            quit()



if __name__ == '__main__':
    main()

