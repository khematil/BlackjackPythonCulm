
import random
 # Dealer cards
dealercards = []
 # Player cards
playercards = []

while len(dealercards) != 2: #if list doesn't = to 2 integers
    dealercards.append(random.randint(1, 11))
    if len(dealercards) == 2: #auto fills it with 2
        print("Dealer has [Hidden] +", dealercards[1])

# Player Cards
while len(playercards) != 2: #if list doesnt = to 2 integers
    playercards.append(random.randint(1, 11))
    if len(playercards) == 2: #autofill
        print("You have ", playercards)

 # Sum of the Dealer cards
if sum(dealercards) == 21: #if dealer == 21 they win
    print("Dealer has 21 and wins!")
elif sum(dealercards) > 21: #if dealer goes over 21 they bust
    print("Dealer has busted!")

# Sum of the Player cards
while sum(playercards) < 21: #if player has less than 21 they can
    hitorstay = str(input("Do you want to stay or hit?  "))
    if hitorstay == "hit": #if user types in hit it will pick another card
        playercards.append(random.randint(1, 11))
        print("You now have a total of " + str(sum(playercards)) + " from these cards ", playercards)
    else: #displays dealer cards
        print("The dealer has a total of " + str(sum(dealercards)) + " with ", dealercards)
        print("You have a total of " + str(sum(playercards)) + " with ", playercards)
        if sum(dealercards) > sum(playercards):
            print("Dealer wins!")
        else:
            print("You win!")
            break

if sum(playercards) > 21: #if player goes over 21 they bust
    print("You busted! Dealer wins this time.")
elif sum(playercards) == 21: #if they equal to 21 they win blackjack
    print("You have blackjack! You Win!")

